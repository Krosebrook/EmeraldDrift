import IntegrationHub from '../components/integrations/IntegrationHub';

export default IntegrationHub;