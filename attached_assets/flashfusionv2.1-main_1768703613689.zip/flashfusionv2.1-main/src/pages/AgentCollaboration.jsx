import AgentCollaborationHub from '../components/agents/AgentCollaborationHub';

export default AgentCollaborationHub;