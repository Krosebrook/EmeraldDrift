import VisualWorkflowBuilder from '../components/workflows/VisualWorkflowBuilder';

export default AdvancedWorkflows;

function AdvancedWorkflows() {
  return <VisualWorkflowBuilder />;
}