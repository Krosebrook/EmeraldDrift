// Placeholder file, this should be overridden by the generated code

export default function Home() {
  return <div></div>;
}
