export { emailNotificationService } from './EmailNotificationService';
export type { EmailTemplate, EmailRecipient, EmailOptions, NotificationType } from './EmailNotificationService';
