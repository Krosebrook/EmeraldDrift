/**
 * Shared utilities and types module
 */

export * from './result';
